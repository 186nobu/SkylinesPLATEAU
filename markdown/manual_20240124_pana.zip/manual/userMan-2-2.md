## 2. 3D都市モデルのダウンロード

------

ゲーム上に再現したい都市の3D都市モデルをダウンロード（※1）し、任意（デスクトップ等）の場所に保存する。 

① G空間情報センター3D都市モデル（Project PLATEAU）ポータルサイト（https://www.geospatial.jp/ckan/dataset/plateau）をブラウザで開く。

② リンクから任意の都市のデータセットページに進み、データ欄の「CityGML」をクリック。

③ CityGMLのページで「ダウンロード」ボタンをクリックし、ファイルをダウンロード、Zipファイルを展開する（保存場所はどこでもよい）。

<br><img src="../resources/userMan/1-2-1-1.png" style="zoom: 22%;" />

<br>
<br>

※1　サンプルデータ（茨城県鉾田市の3D都市モデルの一部データ）を使用する場合は
 https://github.com/Project-PLATEAU/UC22-010-SkylinesPLATEAU/blob/main/SampleData/08234_hokota-shi_2020_citygml_4_op_sample_area.zip をダウンロードする。

<br>
<br>
